return {'nvim-telescope/telescope.nvim'}
