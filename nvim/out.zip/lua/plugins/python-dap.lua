return {
    'mfussenegger/nvim-dap-python'
}
