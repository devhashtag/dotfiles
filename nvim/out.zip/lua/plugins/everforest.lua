return {
    "sainnhe/everforest",
    priority = 1000,
    config = function() end
}
