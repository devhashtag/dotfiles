-- lua/plugins/jdtls.lua

local function get_project_root()
    -- Check for pom.xml, build.gradle, or .git in ancestor directories
    local marker = 'pom.xml'
    local current_file = vim.api.nvim_buf_get_name(0)

    local root = vim.fn.finddir(marker, vim.fn.fnamemodify(current_file, ':h') .. ';')
    
    -- If root is found (not empty/0), return it, otherwise return current directory
    if root and root ~= '' and root ~= '0' then
        return root
    else
        return vim.fn.getcwd()
    end
end


return {
  "mfussenegger/nvim-jdtls",
  ft = { "java" },
  config = function() 
    local dap = require('dap')
    local jdtls = require('jdtls')
    local root_dir = get_project_root()
    local project_name = vim.fn.fnamemodify(root_dir, ':t')

    local config = {
        type = 'java',
        request = 'launch',
        name = 'Debug ' .. project_name,
        mainClass = '${file}',
        projectName = project_name,
        cwd = root_dir,
        cmd = { 'java', '-jar' }, 
        init_options = {
            bundles = {
                vim.fn.glob('/Users/peterheijstek/Repositories/java-debug/com.microsoft.java.debug.plugin/target/com.microsoft.java.debug.plugin-*.jar')
            }
        },
        on_attach = function(client, bufnr)
            jdtls.setup_dap({ hotcodereplace = 'auto'})

            local opts = { noremap = true, silent = true, buffer = bufnr }
            vim.keymap.set("n", "gd", vim.lsp.buf.definition, opts)
            vim.keymap.set("n", "gr", vim.lsp.buf.references, opts)
            vim.keymap.set("n", "gi", vim.lsp.buf.implementation, opts)
            vim.keymap.set("n", "K", vim.lsp.buf.hover, opts)
            vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename, opts)
            vim.keymap.set("n", "<leader>ca", vim.lsp.buf.code_action, opts)

            -- Java-specific helpers
            vim.keymap.set("n", "<leader>oi", jdtls.organize_imports, opts)
            vim.keymap.set("n", "<leader>ev", jdtls.extract_variable, opts)
            vim.keymap.set("n", "<leader>ec", jdtls.extract_constant, opts)
            vim.keymap.set("x", "<leader>em", jdtls.extract_method, opts)
        end
    }

    require('jdtls').start_or_attach(config)
  end
}

