return {
    'mfussenegger/nvim-dap',
    setup = function() end
}
